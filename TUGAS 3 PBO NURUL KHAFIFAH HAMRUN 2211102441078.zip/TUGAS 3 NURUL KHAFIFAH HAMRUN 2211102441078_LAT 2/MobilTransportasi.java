import greenfoot.*;

public class MobilTransportasi extends Mobil {
    private int jmlKursi;
    
    public MobilTransportasi(int jmlKursi) {
        this.jmlKursi = jmlKursi;
    }
    
    public void tambahPenumpang() {
        // Eksekusi untuk menambahkan penumpang pada mobil transportasi
    }
}