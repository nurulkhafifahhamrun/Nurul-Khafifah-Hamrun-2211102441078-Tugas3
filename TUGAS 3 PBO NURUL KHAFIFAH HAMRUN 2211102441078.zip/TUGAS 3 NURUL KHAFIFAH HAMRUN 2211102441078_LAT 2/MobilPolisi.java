import greenfoot.*;

public class MobilPolisi extends MobilNegara {
    public void NyalakanTape() {
        // eksekusi untuk menyalakan Tape pada mobil polisi
    }
    
    public void NyalakanTV() {
        // eksekusi untuk menyalakan TV pada mobil polisi
    }
    
    public void NyalakanAC() {
        // eksekusi untuk menyalakan AC pada mobil polisi
    }
    
    public void NyalakanMesin() {
        // eksekusi untuk menyalakan mesin pada mobil polisi
    }
    
    public void MatikanMesin() {
        // eksekusi untuk mematikan mesin pada mobil polisi
    }
    
    public void TambahGerigi() {
        // eksekusi untuk menambahkan gerigi pada mobil polisi
    }
    
    public void TurunkanGerigi() {
        // eksekusi untuk menurunkan gerigi pada mobil polisi
    }
    
    public void TekanGas() {
        // eksekusi untuk menekan Gas pada mobil polisi
    }
    
    public void TekanRem() {
        // eksekusi untuk menekan Rem pada mobil polisi
    }
    
    public void NyalakanSirine() {
        // eksekusi untuk menyalakan sirine pada mobil polisi
    }
    
    public void MatikanSirine() {
        // eksekusi untuk mematikan sirine pada mobil polisi
    }
    
    public void GantiSirine(int jenis) {
        // eksekusi untuk mengganti jenis sirine pada mobil polisi
    }
    
    public void NyalakanRadioHT() {
        // eksekusi untuk menyalakan radio HT pada mobil polisi
    }
    
    public void MatikanRadioHT() {
        // eksekusi untuk mematikan radio HT pada mobil polisi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}