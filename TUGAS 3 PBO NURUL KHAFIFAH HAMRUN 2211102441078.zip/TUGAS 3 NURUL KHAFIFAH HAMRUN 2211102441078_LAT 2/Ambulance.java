import greenfoot.*;

public class Ambulance extends MobilNegara {
    public void NyalakanTape() {
        // Eksekusi untuk menyalakan tape pada ambulance
    }
    
    public void NyalakanTV() {
        // Eksekusi untuk menyalakan TV pada ambulance
    }
    
    public void NyalakanAC() {
        // Eksekusi untuk menyalakan AC pada ambulance
    }
    
    public void NyalakanMesin() {
        // Eksekusi untuk menyalakan Mesin pada ambulance
    }
    
    public void MatikanMesin() {
        // Eksekusi untuk mematikan Mesin pada ambulance
    }
    
    public void NyalakanSirine() {
        // Eksekusi untuk menyalakan sirine pada ambulance
    }
    
    public void MatikanSirine() {
        // Eksekusi untuk mematikan sirine pada ambulance
    }
    
    public void TambahGerigi() {
        // Eksekusi untuk menambahkan gerigi pada ambulance
    }
    
    public void TurunkanGerigi() {
        // Eksekusi untuk menurunkan gerigi pada ambulance
    }
    
    public void TekanGas() {
        // Eksekusi untuk menekan gas pada ambulance
    }
    
    public void TekanRem() {
        // Eksekusi untuk menekan rem pada ambulance
    }

    
    public void gantiSirine(int jenis) {
        // Eksekusi untuk mengganti jenis sirine pada ambulance
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}