import greenfoot.*;

public class Bus extends MobilPribadi {
    public void NyalakanTape() {
        // eksekusi untuk menyalakan tape pada bus
    }
    
    public void NyalakanTV() {
        // eksekusi untuk menyalakan TV pada bus
    }
    
    public void NyalakanAC() {
        // eksekusi untuk menyalakan AC pada bus
    }
    
    public void NyalakanMesin() {
        // eksekusi untuk menyalakan Mesin pada ambulance
    }
    
    public void MatikanMesin() {
        // eksekusi untuk mematikan Mesin pada ambulance
    }
    
    public void TambahGerigi() {
        // eksekusi untuk menambahkan gerigi pada mobil polisi
    }
    
    public void TurunkanGerigi() {
        // eksekusi untuk menurunkan gerigi pada mobil polisi
    }
    
    public void TekanGas() {
        // eksekusi untuk menekan Gas pada mobil polisi
    }
    
    public void TekanRem() {
        // eksekusi untuk menekan Rem pada mobil polisi
    }
    
    public void tambahPenumpang() {
        // Eksekusi untuk menambahkan penumpang pada mobil transportasi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}