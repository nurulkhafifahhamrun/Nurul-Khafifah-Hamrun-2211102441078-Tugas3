import greenfoot.*;

public class MobilPribadi extends Mobil {
    public void NyalakanTape() {
        // Eksekusi untuk menyalakan tape pada mobil pribadi
    }
    
    public void NyalakanTV() {
        // Eksekusi untuk menyalakan TV pada mobil pribadi
    }
    
    public void NyalakanAC() {
        // Eksekusi untuk menyalakan AC pada mobil pribadi
    }
    
    public void NyalakanMesin() {
        // Eksekusi untuk menyalakan Mesin pada mobil pribadi
    }
    
    public void MatikanMesin() {
        // Eksekusi untuk mematikan Mesin pada mobil pribadi
    }
    
    public void TambahGerigi() {
        // Eksekusi untuk menambahkan Gerigi pada mobil pribadi
    }
    
    public void TurunkanGerigi() {
        // Eksekusi untuk menurunkan Gerigi pada mobil pribadi
    }
    
    public void TekanGas() {
        // Eksekusi untuk menekan Gas pada mobil pribadi
    }
    
    public void TekanRem() {
        // Eksekusi untuk menekan Rem pada mobil pribadi
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}