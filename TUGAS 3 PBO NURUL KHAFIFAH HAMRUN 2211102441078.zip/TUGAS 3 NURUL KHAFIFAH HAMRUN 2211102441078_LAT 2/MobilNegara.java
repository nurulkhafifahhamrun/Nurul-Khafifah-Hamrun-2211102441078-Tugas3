import greenfoot.*;

public class MobilNegara extends Mobil {
    public void NyalakanTape() {
        // eksekusi untuk menyalakan tape pada mobil negara
    }
    
    public void NyalakanTV() {
        // eksekusi untuk menyalakan TV pada mobil negara
    }
    
    public void NyalakanAC() {
        // eksekusi untuk menyalakan AC pada mobil negara
    }
    
    // Metode dan perilaku lainnya sesuai dengan kebutuhan Anda
}