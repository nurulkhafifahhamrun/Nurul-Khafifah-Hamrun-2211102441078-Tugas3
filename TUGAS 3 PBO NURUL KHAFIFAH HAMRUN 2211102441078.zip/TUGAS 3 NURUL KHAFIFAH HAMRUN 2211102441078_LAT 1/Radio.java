import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Radio extends Actor implements InterfaceElektronik, InterfaceChannelRadio {
    private boolean mesin;
    private int volume;
    
    public Radio() {
        mesin = false;
        volume = 0;
    }
    
    public void on() {
        mesin = true;
    }
    
    public void off() {
        mesin = false;
    }
    
     public void gantiChannel(int c) {
        // eksekusi penggantian channel pada radio
    }
    
    public void perbesarVolume() {
        // eksekusi peningkatan volume pada radio
    }
    
    public void perkecilVolume() {
        // eksekusi penurunan volume pada radio
    }
    
    public void act() {
        // eksekusi perilaku aktor Radio di setiap siklus aksi
    }
}


